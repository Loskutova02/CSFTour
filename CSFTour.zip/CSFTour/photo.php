﻿
          <div class="wrapper">
               <ul class="min">
                    <li><a  href="#img1"><img width="150" height="83" src="images/min1.jpg" /></a></li>
                    <li><a  href="#img2"><img width="150" height="83" src="images/min2.jpg" /></a></li>
                    <li><a  href="#img3"><img width="150" height="83" src="images/min3.jpg" /></a></li>
                    <li><a  href="#img4"><img width="150" height="83" src="images/min4.jpg" /></a></li>
                    <li><a  href="#img5"><img width="150" height="83" src="images/min5.jpg" /></a></li>
               </ul>
               <div class="images">
                    <div><a name="img1"></a><img width="100%" alt="" src="images/img1.jpg" /></div>
                    <div><a name="img2"></a><img width="100%" alt="" src="images/img2.jpg" /></div>
                    <div><a name="img3"></a><img width="100%" alt="" src="images/img3.jpg" /></div>
                    <div><a name="img4"></a><img width="100%" alt="" src="images/img4.jpg" /></div>
                    <div><a name="img5"></a><img width="100%" alt="" src="images/img5.jpg" /></div>
               </div>
          </div>
		  
<table border="2">
<tr>
<td>Город</td>
<td>Отель</td>
<td>Адрес</td>
<td>Класс отеля</td>
</tr>
<tr>
<td>Турция, Средиземноморский регион, Белек</td>
<td>Maxx Royal Belek Golf Resort 5*</td>
<td>iskele Mevkii Belek, Antalya, ТУРЦИЯ</td>
<td>4.87</td>
</tr>
<tr>
<td>Солнечный берег Бургасская область Болгария</td>
<td>Helena Park 5*</td>
<td>8240 - Sunny Beach - Bulgaria</td>
<td>4.71</td>
</tr>
<tr>
<td>Греция, Крит о., Георгиуполис</td>
<td>Pilot Beach Resort and Spa 5*</td>
<td>73007 GEORGIOPOULIS, CHANIA, CRETE, GREECE</td>
<td>4.67</td>
</tr>
<tr>
<td>Окурджалар Аланья Средиземноморский регион Турция</td>
<td>Justiniano Club Park Conti 5*</td>
<td>Alara Turizm Merkezi - Okurcalar - Karaburun - Alanya - Antalya / TURKIYE</td>
<td>4.45</td>
</tr>
<tr>
<td>ОАЭ, Эмират Дубай, Дубай, Палм Джумейра</td>
<td>Rixos The Palm Dubai 5*</td>
<td>The Palm Jumeirah, East Crescent, Plot C40 P.O.Box: 18652 – Dubai, United Arab Emirates</td>
<td>4.2</td>
</tr>
</table> 
		
