<table   width = 100%  valign = top>
<tr>


<br>
<section id="content">
<h1>Добавление местопребывания:
<form class="mainform" action = "scr_action.php?action=new_hotel" method = "POST""><h1>

<p class="name">
		<h2>Название отеля: <br> <input type = "text" name = "name" size = 40 value = "" 
		placeholder="Название отеля" required/>
        <br><br></h2></p>
<p class="msg">
<h2>Место расположения: <br><textarea  style="width:300px; height:150px;" name = "region" pattern="^[А-Яа-яЁё\s]+$" placeholder="Место расположения"  required></textarea><br><br></h2></p>
<br>
<p class="send" >
<input type = "submit" name = "ok" value = "Добавить отель">
</p>
</section>
</form>





<br><br><br><br><br><br><br><br><br><br>
</table>
